<?php
/**
 * Created by PhpStorm.
 * User: jordan
 * Date: 4/19/17
 * Time: 12:49 PM
 */
include('EZPlanR_Model.php');
echo'<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">';

echo'<table class="highlight responsive-table">';
echo'<thead>';
echo'<tr>                
         <th>Student ID</th>
         <th>First Name</th>
         <th>Last Name</th>
     </tr>';
echo '</thead>';
/*if($_SERVER["REQUEST_METHOD"] == "POST") { //looping through to check each student found in first query
    if($_POST['FinalizeRoster']){*/
foreach($connect->query("SELECT * FROM user, student WHERE user.User_ID = student.User_ID ")as $megadooty){
    if(IsChecked('students', $megadooty['Student_ID'])){
        //$preparedQueries[] = "ROM'"
        $arraySelected[] = $megadooty['Student_ID'];
        //addStudentToRoster();
        echo '<div id="selection">';
        echo '<tr>',
        '<td>', $megadooty['Student_ID'], '</td>',
        '<td>', $megadooty['First_Name'], '</td>',
        '<td>', $megadooty['Last_Name'], '</td>';
        echo '</tr>';
        echo '</div>';
    }

}
echo '<button class="btn waves-effect waves-light" name="FinalizeRoster" type="submit" 
             formaction="finalize_roster.php">Finalize Roster</button>';
echo '</table>';

if($_SERVER[''])
        if (!empty($_POST['RosterName'])) {

            addRoster($_POST['rosterName']);//,$arraySelected[],);
            foreach($connect->query("SELECT Student_ID FROM student WHERE user.User_ID = student.User_ID ") as $addedStudent)

                addStudentToRoster($rosterName, $addedStudent);
            //$RosterName = $_POST['RosterName'];
                header('Location: http://' . $_SERVER['HTTP_HOST'] . '/EZPlanR_1.0.2/teacher_base_view.php');

        } else {
            header('Location:  http://' . $_SERVER['HTTP_HOST'] . '/EZPlanR_1.0.2/roster_view.php');
            exit;
        }



    //$studentArray[] = $megadooty['Student_ID'];
