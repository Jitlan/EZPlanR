<?php
//Thank-you, Anthony Lagrotta, for being the wonderful man you are.
include ('EZPlanR_Model.php');
include ('roster_view.php');


echo'<form id = "createRosterForm" name="addRoster" action="add_Roster.php" method="POST">';

echo'<div id = "container_selected" class="card-panel hoverable">';
echo'<table class="highlight responsive-table">';
echo'<thead>';
echo'<input type="text" name="RosterName" id="RosterName" placeholder="Please enter a roster name." maxlength="20">

                <tr>                
                    <th>Student ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                </tr>';
echo '</thead>';

function IsChecked($checkboxname,$value){
    if(!empty($_POST[$checkboxname])){//posted checkboxes, not every checkbox
        foreach($_POST[$checkboxname] as $checkvalue){//loops to see if the POSTED check box is checked
            if($checkvalue == $value){
                return true;//lets figure it out! together :)
            }
        }
    }
    return false;
}

    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <?php
    echo "<br>";
global $connect;
if($_SERVER["REQUEST_METHOD"] == "POST"){
       if(!empty($_POST['students'])){
           $i = 1;
           $rosterName = $_POST['RosterName'];
           //MAKE AND USE INSERT FUNCTION FROM MODEL. MAKE WORK WITH REST
           //looping through to check each student found in first query
           foreach($connect->query("SELECT * FROM user, student WHERE user.User_ID = student.User_ID ")as $megadooty){
               if(IsChecked('students', $megadooty['Student_ID'])){
                //$preparedQueries[] = "ROM'"
                   $arraySelected[] = $megadooty['Student_ID'];
                   //addStudentToRoster();
                   echo '<div id="selection">';
                   echo '<tr>',
                   '<td>', $megadooty['Student_ID'], '</td>',
                   '<td>', $megadooty['First_Name'], '</td>',
                   '<td>', $megadooty['Last_Name'], '</td>';
                   echo '</tr>';
                   echo '</div>';
               }
           }
       }
    echo '<button class="btn waves-effect waves-light" name="FinalizeRoster" type="submit" 
             formaction="finalize_roster.php?action=createRoster">Finalize Roster</button>';
    echo '</table>';
    echo '</div>';
    echo '</form>';
}

//query students and users again, compare that result with $i to see if its selected, and then print that row.
?>

